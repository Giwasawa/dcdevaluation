from setuptools import setup

setup(name     = 'dcdevaluation',
      version  = '0.4'              ,
      packages = ['dcdevaluation']     ,
      zip_safe = False              )
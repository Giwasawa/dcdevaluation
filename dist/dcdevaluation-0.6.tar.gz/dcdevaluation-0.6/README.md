# dcdevaluation
Python library aimed at optimizing the model evaluating process

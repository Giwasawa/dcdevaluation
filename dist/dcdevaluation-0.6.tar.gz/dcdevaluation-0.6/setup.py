from setuptools import setup

setup(name     = 'dcdevaluation',
      version  = '0.6'              ,
      packages = ['dcdevaluation']     ,
      zip_safe = False              )